# PartySpot
Een Flutter-app om feestjes in Nederland te vinden.